//#define DRAWING1
#define DRAWING
//#define FREEFEM
//#define TEST 100
//#define DEBUG
