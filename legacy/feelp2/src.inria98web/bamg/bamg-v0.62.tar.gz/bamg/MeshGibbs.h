void  Gibbs(Triangles* );
